| type                        | dish                        |
| ----------------------------|-----------------------------|
| starter                     | permissions salad           |
| main course                 | hard drive meat             |
| side                        | corrupted file name carrots |
| veggie                      | fried bytes                 |
| dessert                     | short cut pudding           |
