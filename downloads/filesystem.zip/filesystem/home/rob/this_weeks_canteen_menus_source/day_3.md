| type                        | dish                        |
| ----------------------------|-----------------------------|
| starter                     | shortcut soup               |
| main course                 | manpage steak medaillon          |
| side                        | mashed network potatoes |
| veggie                      | fried terminal zucchini |
| dessert                     | solarized ice cream         |
