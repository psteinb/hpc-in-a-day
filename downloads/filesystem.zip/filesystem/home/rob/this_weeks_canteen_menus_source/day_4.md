| type                        | dish                        |
| ----------------------------|-----------------------------|
| starter                     | revision nightmare soup     |
| main course                 | entre-bad-code steak                 |
| side                        | french open source fries|
| veggie                      | cheese rolls in a ssh tunnel  |
| dessert                     | creme brullee a la LSF      |
