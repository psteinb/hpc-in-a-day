| type                        | dish                        |
| ----------------------------|-----------------------------|
| starter                     | admin's delight             |
| main course                 | small file pasta bolognese  |
| side                        | rack rice                   |
| veggie                      | small file pasta with basil sauce |
| dessert                     | unit test fruit salad       |
